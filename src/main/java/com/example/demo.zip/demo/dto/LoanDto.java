package com.example.demo.dto;
import lombok.Data;

@Data
public class LoanDto {

    private String loan_origin_amount;
    private String interest_rate;

}


