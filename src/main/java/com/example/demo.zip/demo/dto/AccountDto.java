package com.example.demo.dto;

import lombok.Data;

@Data
public class AccountDto {

        private String userId;
        private String userName;
        private String password;
        private String email;
        private String phoneNumber;

}



